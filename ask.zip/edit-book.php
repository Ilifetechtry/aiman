<?php include 'sidebar.php'?>
<body class="nk-body" data-sidebar-collapse="lg" data-navbar-collapse="lg" style="margin-top:40px">
<?php 
    $sel=mysqli_query($conn,"SELECT* FROM book WHERE id='".$_GET['id']."' ");
    if(mysqli_num_rows($sel)>0){
        $fe=mysqli_fetch_assoc($sel);
    }
?>
<style>
    spam{
        color:red;
    }
</style>
<div class="nk-content">
        <div class="container">
        <div class="nk-content-inner">
        <div class="nk-content-body">
        <div class="nk-block-head">
        <div class="nk-block-head-between flex-wrap gap g-2">
        <div class="nk-block-head-content"><h2 class="nk-block-title">Edit book</h1><nav><ol class="breadcrumb breadcrumb-arrow mb-0"><li class="breadcrumb-item"><a href="#">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Book</li>
        <li class="breadcrumb-item active" aria-current="page">Edit Book</li>
    </ol></nav></div>
    <div class="nk-block-head-content"><ul class="d-flex">
        <li><a href="book.php" class="btn btn-primary btn-md d-md-none"><em class="icon ni ni-eye"></em><span>View</span></a></li>
        </ul></div></div></div>
    <div class="nk-block">
<form method="post" enctype="multipart/form-data">
        <div class="row g-gs">
        <div class="col-xxl-12">
        <div class="gap gy-4">
        <div class="gap-col">
        <div class="card card-gutter-md">
        <div class="card-body">
        <div class="row g-gs">

    <div class="col-lg-5">
    <div class="form-group"><label class="form-label">Book Name <spam>*</spam>        
    </label>
    <div class="form-control-wrap"><input type="text" class="form-control"  name="book_name" value="<?=$fe['book_name'];?>"></div></div></div>

    <div class="col-lg-3">
    <div class="form-group"><label for="bookname" class="form-label">Uploaded Date<spam>*</spam></label>
<div class="form-control-wrap">
<input type="date" id="datetime" name="upload_date" value="<?=$fe['upload_date'];?>" class='form-control'>
    
</div></div></div>
    <div class="col-lg-2">
        <div class="form-group"><label class="form-label">Book Price <spam>*</spam></label>
    <div class="form-control-wrap"><input type="text" class="form-control" placeholder="Total price" name="book_price" value="<?=$fe['book_price'];?>">
    </div></div></div>

    <div class="col-lg-2">
        <div class="form-group"><label class="form-label">Book Stock <spam>*</spam></label>
    <div class="form-control-wrap"><input type="text" class="form-control" placeholder="Total price" name="book_stock" value="<?=$fe['book_stock'];?>">
    </div></div></div>

    <div class="col-lg-12">
        <div class="form-group">
            <?php
            if($fe['book_image']){
            ?>
                <center class='mt-3 no_book'>
                    <h3 class='text-danger d-none'>No Book Photo!</h3>
                </center>
                <label class="form-label">Change Book Image</label>
                <br>
                <img src="uploads/<?=$fe['book_image']?>" alt="" id='myBookImg' height='170'>
                <br>
            <?php
            }
            else{
            ?>
                <img  id='myBookImg' style='max-height:200px;'  class='mb-3'>
                <br>
                <center class='mt-3 no_book'>
                    <h3 class='text-danger'>No Book Photo!</h3>
                </center>
                <label class="form-label">Upload Book Image</label>
            <?php
            }
            ?>
            <div>
                <input id="book_image" name="book_image" type="file" max="1" accept='image/*' class='form-control mt-2'>
            </div>
        </div>
    </div>  

    <div class="col-lg-12">
    <div class="form-group"><label class="form-label">Remarks</label>
    <div class="form-control-wrap">
        <textarea name="remarks" id="" class="form-control"><?=$fe['remarks'];?></textarea>
    </div></div></div>
    </div></div></div></div></div></div>
<div class="row" style="margin-top:20px">
<div class="col-9"></div>
<div class="col-3 text-end">
        <input type="submit" name="submit" value="Update Book" class="btn btn-primary" class="form-control">
        </div>
    </div>
    </div></div></div>
</form>
        </body>
        <script src="assets/js/bundle.js"></script>
        <script src="assets/js/scripts.js"></script>            
<link rel="stylesheet" href="assets/css/libs/editors/quill20d4.css?v1.1.2"></link>
<script src="assets/js/libs/editors/quill.js"></script>
<script src="assets/js/editors/quill.js"></script>
</html>
<script>
    let book_image=document.querySelector("#book_image");
    let myBookImg=document.querySelector("#myBookImg");
    let no_book=document.querySelector(".no_book");
    book_image.addEventListener('change',(e)=>{
        const image=URL.createObjectURL(e.target.files[0]);
        console.log(image);
        no_book.style.display='none';
        myBookImg.src=image;
    })
</script>


<?php
    if(isset($_POST['submit']))
    {
        $upd=mysqli_query($conn,"UPDATE book 
                SET book_name='".$_POST['book_name']."',
                book_price='".$_POST['book_price']."',
                remarks='".$_POST['remarks']."',
                book_stock='".$_POST['book_stock']."',
                upload_date='".$_POST['upload_date']."'

                WHERE id='".$_GET['id']."'");

        if($_FILES["book_image"]["tmp_name"]!=''){
        $target_dir = "uploads/"; // Your upload directory
        $timestamp = time(); // Current timestamp
        $imageFileType = pathinfo($_FILES["book_image"]["name"], PATHINFO_EXTENSION); // Get file extension        
        $target_file2 = $target_dir . $timestamp . "." . $imageFileType; // Rename with timestamp
        $target_file3 = $timestamp . "." . $imageFileType; // Rename with timestamp
        if($check2 !== false){
        if(move_uploaded_file($_FILES["book_image"]["tmp_name"],$target_file2)){
        $ins=mysqli_query($conn,"UPDATE book set book_image='".$target_file3."' where id='".$_GET['id']."'");
    ?>
    <?php
                    }
                        }
                    }
?>
                <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Updated Successfully',
                    confirmButtonText: 'OK'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = "book.php";
                    }
                }); 
            </script>
        <?php
    }
    
?>