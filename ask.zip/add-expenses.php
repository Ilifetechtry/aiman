<?php include 'sidebar.php';?>
<body class="nk-body" data-sidebar-collapse="lg" data-navbar-collapse="lg"style="margin-top:40px">
<script src="assets/js/bundle.js"></script><script src="assets/js/scripts.js"></script>
<style>
    spam{
        color:red;
    }
    label{
        text-transform:capitalize;
    }
</style>
<div class="nk-content">
<div class="container">
<div class="nk-content-inner">
<div class="nk-content-body">
<div class="nk-block-head">
<div class="nk-block-head-between flex-wrap gap g-2">
<div class="nk-block-head-content"><h2 class="nk-block-title">Add Expenses</h1>
<nav>
    <ol class="breadcrumb breadcrumb-arrow mb-0">
        <li class="breadcrumb-item"><a href="#">Home</a></li>
        <li class="breadcrumb-item"><a href="#">Expenses</a></li>
        <li class="breadcrumb-item active" aria-current="page">Add Expenses</li>
    </ol>
</nav>
</div>
<div class="nk-block-head-content"><ul class="d-flex"><li>
    <a href="expenses.php" class="btn btn-primary btn-md d-md-none">
        <em class="icon ni ni-eye"></em><span>View</span></a></li><li>
    <a href="expenses.php" class="btn btn-success d-none d-md-inline-flex"><em class="icon ni ni-eye"></em><span>View All expenses</span></a></li>
</ul></div></div></div>
<div class="nk-block">
<?php
if(isset($_POST['submit'])){
    $ins=mysqli_query($conn,"INSERT INTO expenses (bid,name,price,remarks,date,quantity) VALUES 
    ('".$_POST['bid']."','".$_POST['name']."','".$_POST['price']."','".$_POST['remarks']."','".$_POST['date']."','".$_POST['quantity']."')");
    $iddd=mysqli_insert_id($conn);
    if($_FILES["upload_media"]["tmp_name"]!=''){
    $target_dir = "uploads/";
    $target_file2 = $target_dir . basename($_FILES["upload_media"]["name"]);
    $check2 = getimagesize($_FILES["upload_media"]["tmp_name"]);
    if($check2 !== false){
        if(move_uploaded_file($_FILES["upload_media"]["tmp_name"],$target_file2)){
        $ins=mysqli_query($conn,"UPDATE expenses set upload_media='".$target_file2."' where id='".$iddd."'");
        ?>
<?php
    }
        }
    }
    ?>
            <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Added Successfully',
                    confirmButtonText: 'OK'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = "expenses.php";
                    }
                }); 
            </script>
<?php
}
        $sel=mysqli_query($conn,"SELECT max(id) from expenses");
        if(mysqli_num_rows($sel)>0){
            $fe=mysqli_fetch_array($sel);
            $fes=$fe[0];
?>
<form action="#" method="post" enctype="multipart/form-data">
<div class="row g-gs">
<div class="col-xxl-12">
<div class="gap gy-4">
<div class="gap-col">
<div class="card card-gutter-md">
<div class="card-body">
<div class="row g-gs">
<div class="col-lg-3">
    <div class="form-group"><label for="productname" class="form-label">Bill Id <spam>*</spam></label>
<div class="form-control-wrap">
    <input required type="text" class="form-control" id="productname" name="bid" placeholder="Bill Id" value="BID-<?=$fes+1;?>"></div></div></div>
<div class="col-lg-3">
    <div class="form-group"><label for="productname" class="form-label">Bill Name <spam>*</spam></label>
<div class="form-control-wrap">
    <input required type="text" class="form-control" id="productname" name="name" placeholder="Name"></div></div></div>

<div class="col-lg-3">
<div class="form-group"><label for="baseprice" class="form-label">Bill Price <spam>*</spam></label>
<div class="form-control-wrap">
    <input required type="text" class="form-control" id="baseprice" name="price" placeholder="Price"></div></div></div>
<div class="col-lg-3">
<div class="form-group"><label for="baseprice" class="form-label">Quantity <spam>*</spam></label>
<div class="form-control-wrap">
    <input required type="text" class="form-control" id="baseprice" name="quantity" value=1 min=0></div></div></div>
    <!-- <div class="col-lg-12">
<div class="form-group"><label for="baseprice" class="form-label">Date <spam>*</spam></label>
<div class="form-control-wrap"> -->
    <input required type="date" value="<?=date('Y-m-d');?>" class="form-control" id="baseprice" name="date" hidden>
<!-- </div></div></div> -->

<div class="col-lg-12">
<div class="form-group"><label class="form-label">Bill Photo</label>

<div class="pt-3">
<input id="upload_media" class='form-control' name="upload_media" type="file" max="1">

</div></div></div>
<div class="col-lg-12">
<div class="form-group"><label for="baseprice" class="form-label">Remarks</label>
<div class="form-control-wrap">
    <textarea name="remarks" placeholder="Remarks" id="" class="form-control"></textarea>
    </div></div></div>
    </div></div></div>
    </div></div></div>
    </div></div></div>
    </div> 
<div class="col-4">
    <input type="submit" name="submit" class="btn btn-primary" value="Save Changes"></div></form>
</body>
</html>

<?php
}
?>