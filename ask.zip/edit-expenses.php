<?php include 'sidebar.php'?>
<body class="nk-body" data-sidebar-collapse="lg" data-navbar-collapse="lg" style="margin-top:40px">
<?php 
    $sel=mysqli_query($conn,"SELECT* FROM expenses WHERE id='".$_GET['id']."' ");
    if(mysqli_num_rows($sel)>0){
        $fe=mysqli_fetch_assoc($sel);
    }
?>
<style>
    spam{
        color:red;
    }
    li,h2{
        text-transform:capitalize;
    }
</style>
<div class="nk-content">
        <div class="container">
        <div class="nk-content-inner">
        <div class="nk-content-body">
        <div class="nk-block-head">
        <div class="nk-block-head-between flex-wrap gap g-2">
        <div class="nk-block-head-content"><h2 class="nk-block-title">Edit expenses</h1><nav><ol class="breadcrumb breadcrumb-arrow mb-0"><li class="breadcrumb-item"><a href="#">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">expenses</li>
        <li class="breadcrumb-item active" aria-current="page">Edit expenses</li>
    </ol></nav></div>
    <div class="nk-block-head-content"><ul class="d-flex">
        <li><a href="expenses.php" class="btn btn-primary btn-md d-md-none"><em class="icon ni ni-eye"></em><span>View</span></a></li>
        </ul></div></div></div>
    <div class="nk-block">
<form method="post" enctype="multipart/form-data">
        <div class="row g-gs">
        <div class="col-xxl-12">
        <div class="gap gy-4">
        <div class="gap-col">
        <div class="card card-gutter-md">
        <div class="card-body">
        <div class="row g-gs">
    <div class="col-lg-9">
    </div>
    <div class="col-lg-3">
    <div class="form-group"><label class="form-label">Bill Number<spam>*</spam>        
    </label>
    <div class="form-control-wrap"><input type="text" class="form-control"  name="bid" value="<?=$fe['bid'];?>" readonly></div></div>
    </div>
    <div class="col-lg-4">
    <div class="form-group"><label class="form-label">Bill Name <spam>*</spam>        
    </label>
    <div class="form-control-wrap"><input type="text" class="form-control"  name="name" value="<?=$fe['name'];?>"></div></div></div>
    <div class="col-lg-4">
        <div class="form-group"><label class="form-label">Bill Price <spam>*</spam></label>
    <div class="form-control-wrap"><input type="text" class="form-control" placeholder="Total price" name="price" value="<?=$fe['price'];?>">
    </div></div></div>
    <div class="col-lg-4">
        <div class="form-group"><label class="form-label">Date <spam>*</spam></label>
    <div class="form-control-wrap"><input type="date" class="form-control" placeholder="Total price" name="date" value="<?=$fe['date'];?>">
    </div></div></div>

    <div class="col-lg-12">
    <div class="form-group"><label class="form-label">Remarks</label>
    <div class="form-control-wrap">
        <textarea name="remarks" id="" class="form-control"><?=$fe['remarks'];?></textarea>
    </div></div></div>
    <div class="gap-col">
<div class="card card-gutter-md">
<div class="card-body">
<div class="form-group"><label class="form-label">Bill Photo</label>
<div class="form-control-wrap">
</div>
<center><img src="<?=$fe['upload_media'];?>" height="150px" width="180px">
<div class="pt-3">
<input  id="upload_media" name="upload_media" type="file" max="1" hidden>
<label for="upload_media" class="btn btn-md btn-primary">Upload Image</label> </center>
    </div></div></div>
    </div></div></div>
    </div></div></div>
    
<div class="row" style="margin-top:20px">
<div class="col-3">
        <input type="submit" name="submit" value="Edit" class="btn btn-primary" class="form-control">
        </div>
    </div>
</form></div></div></div>
        </body>
        <script src="assets/js/bundle.js"></script>
        <script src="assets/js/scripts.js"></script>            
<link rel="stylesheet" href="assets/css/libs/editors/quill20d4.css?v1.1.2"></link>
<script src="assets/js/libs/editors/quill.js"></script>
<script src="assets/js/editors/quill.js"></script>
</html>
<?php
    if(isset($_POST['submit']))
    {
        $upd=mysqli_query($conn,"UPDATE expenses 
                SET name='".$_POST['name']."',
                price='".$_POST['price']."',
                bid='".$_POST['bid']."',
                remarks='".$_POST['remarks']."',
                date='".$_POST['date']."',
                remarks='".$_POST['remarks']."'
                WHERE id='".$_GET['id']."'");
                if($_FILES["upload_media"]["tmp_name"] != "" || $_FILES["avatar"]["tmp_name"] != ""){
                $target_dir = "uploads/";
                $target_file1 = $target_dir . basename($_FILES["upload_media"]["name"]);
                $check1 = getimagesize($_FILES["upload_media"]["tmp_name"]);
                if(move_uploaded_file($_FILES['upload_media']['tmp_name'],$target_file1)){
                    $upd=mysqli_query($conn,"UPDATE expenses SET upload_media='".$target_file1."'WHERE id='".$_GET['id']."'");
                    }
                }
           
?>
            <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Updated Successfully',
                    confirmButtonText: 'OK'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = "expenses.php";
                    }
                }); 
            </script>
        <?php
    }
    
?>