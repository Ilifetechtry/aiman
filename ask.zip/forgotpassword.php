<?php 
    include 'sidebar.php';
?>
<div class="nk-content">
    <div class="container">
    <div class="nk-content-inner">
    <div class="nk-content-body">
    <div class="nk-block-head">
    <h4 class="bio-block-title mb-4">Forgot Password</h4>
<div class="nk-block">
    <div class="tab-content" id="myTabContent">
    <div class="tab-pane show active w-50" id="tab-1" tabindex="0">
    <div class="card card-gutter-md">
    <div class="card-body">
    <div class="bio-block"><form action="#">
    <div class="row g-3">
    <div class="col-lg-12">
    <div class="form-group">
        <label for="password" class="form-label">Hint</label>
<div class="form-control-wrap">
    <input type="password" class="form-control" id="password" name="password" placeholder="Hint">
</div></div></div>
<div class="row g-3">

<div class="col-lg-12">
    <div class="form-group">
        <label for="lastname" class="form-label">New password</label>
    <div class="form-control-wrap">
    <input type="text" class="form-control" id="lastname" placeholder="Set a New Password"></div></div></div>
    <div class="row g-3">
<div class="col-lg-12">
    <div class="form-group">
        <label for="username" class="form-label">Confirm New Password</label>
<div class="form-control-wrap">
    <input type="text" class="form-control" id="username" placeholder="Confirm New Password">
</div></div></div>