    <?php
    $conn=mysqli_connect('localhost','root','','ask');
    if(!$conn){
        die ("connection failed: ".mysqli_connect_error());
    }
?>
