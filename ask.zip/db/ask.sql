-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 31, 2025 at 12:36 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ask`
--

-- --------------------------------------------------------

--
-- Table structure for table `all_tabs`
--

CREATE TABLE `all_tabs` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `category_option` varchar(150) DEFAULT NULL,
  `category_name` varchar(150) DEFAULT NULL,
  `price` varchar(150) DEFAULT NULL,
  `specimen` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `id` int(11) NOT NULL,
  `book_id` varchar(200) DEFAULT NULL,
  `book_name` varchar(255) DEFAULT NULL,
  `book_price` varchar(255) DEFAULT NULL,
  `book_stock` varchar(200) DEFAULT NULL,
  `book_image` varchar(255) DEFAULT NULL,
  `upload_date` varchar(255) DEFAULT NULL,
  `remarks` varchar(266) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`id`, `book_id`, `book_name`, `book_price`, `book_stock`, `book_image`, `upload_date`, `remarks`) VALUES
(8, 'BIKE-1', 'Pulsar150', '70000', '16', '1748516943.png', '2025-05-29', ''),
(9, 'BOOK-9', 'RX100', '90000', '23', '1748610731.png', '2025-05-30', ''),
(10, 'BOOK-10', 'Elesco', '60000', '29', '1748610757.jpg', '2025-05-30', '');

-- --------------------------------------------------------

--
-- Table structure for table `credit`
--

CREATE TABLE `credit` (
  `c_id` int(11) NOT NULL,
  `bill_id` int(11) DEFAULT NULL,
  `check_credit` int(11) NOT NULL,
  `cname` varchar(100) DEFAULT NULL,
  `date` varchar(200) DEFAULT NULL,
  `due_amount` varchar(11) DEFAULT NULL,
  `paid_amount` int(11) DEFAULT NULL,
  `balance_amount` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `credit`
--

INSERT INTO `credit` (`c_id`, `bill_id`, `check_credit`, `cname`, `date`, `due_amount`, `paid_amount`, `balance_amount`) VALUES
(1, 5, 0, 'Diwakar', '2025-05-09', '460', 100, '100'),
(2, 22, 0, 'Joshwa', '2025-05-14', '5634', 0, '4834'),
(3, 23, 0, 'Ajay', '2025-05-10', '7280', 1000, '6280'),
(4, 24, 0, 'Vijay', '2025-05-14', '7230', 0, '6230'),
(5, 25, 0, 'Vijay', '2025-05-14', '3640', 0, '2640'),
(6, 34, 0, 'Ranjan', '2025-05-30', '94500', 4000, '50500'),
(9, 35, 0, 'Joshwa', '2025-05-31', '94500', 3000, '40000');

-- --------------------------------------------------------

--
-- Table structure for table `credit1`
--

CREATE TABLE `credit1` (
  `c_id` int(11) NOT NULL,
  `bill_id` int(11) DEFAULT NULL,
  `check_credit` int(11) NOT NULL,
  `cname` varchar(100) DEFAULT NULL,
  `date` varchar(200) DEFAULT NULL,
  `due_amount` int(11) NOT NULL,
  `paid_amount` int(11) NOT NULL,
  `balance_amount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `credit1`
--

INSERT INTO `credit1` (`c_id`, `bill_id`, `check_credit`, `cname`, `date`, `due_amount`, `paid_amount`, `balance_amount`) VALUES
(1, 5, 0, 'Diwakar', '2025-04-08', 460, 60, 400),
(2, 5, 0, 'Diwakar', '2025-04-08', 0, 200, 200),
(3, 5, 0, 'Diwakar', '2025-05-09', 0, 100, 100),
(4, 22, 0, 'Joshwa', '2025-05-10', 1604, 500, 1104),
(5, 23, 0, 'Ajay', '2025-05-10', 7280, 1000, 6280),
(6, 24, 0, 'Vijay', '2025-05-10', 7180, 1000, 6180),
(7, 25, 0, 'Vijay', '2025-05-10', 7180, 1000, 6180),
(8, 22, 0, 'Joshwa', '2025-05-13', 0, 300, 804),
(9, 22, 0, 'Joshwa', '2025-05-14', 5634, 0, 4834),
(12, 22, 0, 'Joshwa', '2025-05-14', 5634, 0, 4834),
(13, 24, 0, 'Vijay', '2025-05-14', 7230, 0, 6230),
(14, 24, 0, 'Vijay', '2025-05-14', 7230, 0, 6230),
(15, 25, 0, 'Vijay', '2025-05-14', 3640, 0, 2640),
(16, 34, 0, 'Ranjan', '2025-05-30', 94500, 40000, 54500),
(17, 34, 0, 'Ranjan', '2025-05-30', 0, 4000, 50500),
(20, 35, 0, 'Joshwa', '2025-05-31', 94500, 50000, 44500),
(21, 35, 0, 'Joshwa', '2025-05-31', 0, 1500, 43000),
(22, 35, 0, 'Joshwa', '2025-05-31', 43000, 3000, 40000);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `cname` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `aadhar` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `cname`, `date`, `mobile`, `email`, `city`, `address`, `aadhar`) VALUES
(17, 'Ranjan', '2025-05-30', '9360648893', '', '', 'Asoor, Trichy', NULL),
(18, 'Edwin', '2025-05-30', '9047789539', NULL, '', 'Sooriyur,<br>Thiruverumbur,<br>Trichy', NULL),
(19, 'Joshwa', '2025-05-30', '9486283460', '', '', 'Thiruvaiyaru,\r\nThanjavur', NULL),
(20, 'Siril', '2025-05-31', '9876543210', '', '', 'Sangarakulam, Thiruppanthuruthi, Thanjavur.', NULL),
(21, 'Ajay', '2025-05-31', '1234567890', NULL, '', 'Nagathi, Ammanpettai, Thanjavur', NULL),
(22, 'Raja', '2025-05-31', '9876543210', NULL, '', 'Trichy', '12345'),
(23, 'Vijay', '2025-05-31', '8765432109', NULL, '', 'Trichy', '9876543210987');

-- --------------------------------------------------------

--
-- Table structure for table `customer1`
--

CREATE TABLE `customer1` (
  `id` int(11) NOT NULL,
  `cid` int(11) DEFAULT NULL,
  `check_id` int(11) NOT NULL,
  `cname` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `c_amount` varchar(255) DEFAULT NULL,
  `r_amount` varchar(255) DEFAULT NULL,
  `mop` varchar(255) DEFAULT NULL,
  `credit_status` int(11) NOT NULL,
  `net_amount` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `tax` varchar(255) DEFAULT NULL,
  `discount` varchar(10) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `price` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `remarks` varchar(100) DEFAULT NULL,
  `category_name` varchar(100) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `category_option` int(11) NOT NULL,
  `courieramt` varchar(225) DEFAULT NULL,
  `aadhar` varchar(225) DEFAULT NULL,
  `color` varchar(225) DEFAULT NULL,
  `chassis` varchar(225) DEFAULT NULL,
  `motor` varchar(225) DEFAULT NULL,
  `controller` varchar(225) DEFAULT NULL,
  `charger` varchar(225) DEFAULT NULL,
  `batterymodel` varchar(225) DEFAULT NULL,
  `batterysn` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer1`
--

INSERT INTO `customer1` (`id`, `cid`, `check_id`, `cname`, `date`, `mobile`, `city`, `c_amount`, `r_amount`, `mop`, `credit_status`, `net_amount`, `total`, `tax`, `discount`, `quantity`, `price`, `address`, `remarks`, `category_name`, `email`, `category_option`, `courieramt`, `aadhar`, `color`, `chassis`, `motor`, `controller`, `charger`, `batterymodel`, `batterysn`) VALUES
(32, 17, 0, 'Ranjan', '2025-05-31', '9360648893', '', '', '', 'Cash', 0, '85000', '89250', '5', '0', '1,', '85000,', 'Asoor, Trichy', '', 'Pulsar150,', NULL, 0, NULL, '1234', 'Red, Black', '12345690', '234567890', '567890', '98658857', '08979ASDFGF', 'POIUY0987'),
(33, 18, 0, 'Edwin', '2025-05-31', '9047789539', '', '', '', 'Cash', 0, '80000', '80325', '5', '3500', '1,', '80000,', 'Sooriyur,<br>Thiruverumbur,<br>Trichy', '', 'Pulsar150,', NULL, 0, NULL, '12345', 'Black ', '1234567890', '1234567', '12345', 'ASDF1234', 'ASDF123445AS', '1234'),
(34, 17, 34, 'Ranjan', '2025-05-30', '9360648893', '', '4000', '50500', 'Credit', 1, '90000', '94500', '5', '0', '1,', '90000,', 'Asoor, Trichy', '', 'RX100,', NULL, 0, '', NULL, 'Black', '1234', '678', '6789', '6789', '678', '6789'),
(35, 19, 0, 'Joshwa', '2025-05-31', '9486283460', '', '3000', '40000', 'Credit', 1, '90000', '94500', '5', '0', '1,', '90000,', 'asdf', '', 'RX100,', NULL, 0, NULL, '1234567890', 'Black', '12345', '12345', '2345', '1234', '1234', '12345'),
(36, 23, 0, 'Vijay', '2025-05-31', '8765432109', '', '', '', 'Cash', 0, '62000', '65100', '5', '0', '1,', '62000,', 'Trichy', '', 'Elesco,', NULL, 0, NULL, '9876543210987', 'Black', '34567', '12345', '5678', '12345', '45678', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `delivery_type`
--

CREATE TABLE `delivery_type` (
  `id` int(11) NOT NULL,
  `delivery_type` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `delivery_type`
--

INSERT INTO `delivery_type` (`id`, `delivery_type`) VALUES
(1, 'Lorry'),
(5, 'Bike');

-- --------------------------------------------------------

--
-- Table structure for table `district`
--

CREATE TABLE `district` (
  `id` int(11) NOT NULL,
  `district` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `district`
--

INSERT INTO `district` (`id`, `district`) VALUES
(1, 'Tiruchirapalli'),
(3, 'palliyagraharam'),
(5, 'Trichy'),
(6, 'Thanjavur'),
(7, 'Palakkari'),
(8, '');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `bid` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `quantity` varchar(100) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `upload_media` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `id` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `check_id` int(11) NOT NULL,
  `c_amount` varchar(255) DEFAULT NULL,
  `r_amount` varchar(255) DEFAULT NULL,
  `mop` varchar(255) DEFAULT NULL,
  `credit_status` int(11) NOT NULL,
  `net_amount` varchar(255) DEFAULT NULL,
  `total` int(255) DEFAULT NULL,
  `tax` varchar(255) DEFAULT NULL,
  `discount` varchar(10) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `price` varchar(100) DEFAULT NULL,
  `category_name` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `remarks` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  `category_option` int(11) NOT NULL,
  `color` varchar(225) DEFAULT NULL,
  `chassis` varchar(225) DEFAULT NULL,
  `motor` varchar(225) DEFAULT NULL,
  `controller` varchar(225) DEFAULT NULL,
  `charger` varchar(225) DEFAULT NULL,
  `batterymodel` varchar(225) DEFAULT NULL,
  `batterysn` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`id`, `cid`, `check_id`, `c_amount`, `r_amount`, `mop`, `credit_status`, `net_amount`, `total`, `tax`, `discount`, `quantity`, `price`, `category_name`, `address`, `remarks`, `date`, `category_option`, `color`, `chassis`, `motor`, `controller`, `charger`, `batterymodel`, `batterysn`) VALUES
(2, 2, 0, '340', '', 'UPI', 0, '340', 340, '0', '0', '1,', '340,', 'Grammer Book,', '55 KK Nagar', 'None', '2025-04-08', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 1, 3, '140', '', 'UPI', 0, '140', 140, '0', '0', '1,', '140,', '9th English Guide,', '42 Indra Nagar Kudil Extension', 'none', '2025-04-08', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 1, 4, '', '', 'Cash', 0, '620', 558, '0', '62', '2,3,', '100,140,', 'Competitive Exam Book,9th English Guide,', '42 Indra Nagar Kudil Extension', 'sample', '2025-04-08', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 1, 5, '60', '400', 'Credit', 0, '460', 460, '0', '0', '2,', '230,', '10th English Guide,', '42 Indra Nagar Kudil Extension', '', '2025-04-08', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 1, 6, '', '', 'Cash', 0, '14000', 14000, '0', '0', '100,', '140,', '9th English Guide,', '42 Indra Nagar Kudil Extension', 'dfgdg', '2025-04-08', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(14, 3, 14, '', '', 'Cash', 0, '1000', 969, '2', '50', '5,', '200,', '10th English Guide,', 'MGR nagar', '', '2025-05-09', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(15, 3, 15, '', '', 'Cash', 0, '1000', 969, '2', '50', '5,', '200,', '10th English Guide,', 'MGR nagar', '', '2025-05-09', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, 3, 16, '', '', 'Cash', 0, '230', 230, '0', '0', '1,', '230,', '10th English Guide,', 'MGR nagar', '', '2025-05-09', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(17, 3, 17, '', '', 'Cash', 0, '230', 230, '0', '0', '1,', '230,', '10th English Guide,', 'MGR nagar', '', '2025-05-09', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18, 3, 18, '', '', 'Cash', 0, '1390', 1223, '10', '278', '3,5,', '230,140,', '10th English Guide,9th English Guide,', 'MGR nagar', '', '2025-05-09', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(19, 2, 19, '', '', 'Cash', 0, '2720', 2661, '3', '136', '8,', '340,', 'Grammer Book,', '55 KK Nagar', '', '2025-05-09', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20, 3, 20, '', '', 'Cash', 0, '2380', 2415, '0', '0', '7,', '340,', 'Grammer Book,', 'Thanjavur', 'Sorry for the late Response.', '2025-05-09', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21, 3, 21, '', '', 'Cash', 0, '1200', 1230, '0', '0', '3,', '400,', '8th English Guide,', 'MGR nagar', '', '2025-05-09', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(22, 3, 22, '', '', 'Credit', 0, '4600', 4619, '10', '10', '8,5,', '400,200,', '8th English Guide,Competitive Exam Book,', 'MGR nagar', '', '2025-05-10', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(23, 2, 23, '1000', '6280', 'Credit', 0, '7000', 7280, '0', '0', '70,', '100,', 'Competitive Exam Book,', '55 KK Nagar', '', '2025-05-10', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(24, 4, 0, '1000', '6180', 'Credit', 0, '6000', 7180, '18', '0', '20,', '300,', 'Competitive Exam Book,', '', '', '2025-05-10', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(25, 5, 0, '1000', '6180', 'Credit', 0, '6000', 7180, '18', '0', '20,', '300,', 'Competitive Exam Book,', '', '', '2025-05-10', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(26, 6, 0, '', '', 'Cash', 0, '4900', 5154, '8', '200', '5,8,', '340,400,', 'Grammer Book,8th English Guide,', '20th Street, Navalpattu Burma Colony, Trichy 620016.', '', '2025-05-10', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(27, 7, 0, '', '', 'Cash', 0, '18120', 17471, '5', '1812', '50,8,', '340,140,', 'Grammer Book,9th English Guide,', '2, Therkuveedi, Kamala silks opp, Thanjavur', '', '2025-05-13', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(28, 8, 28, '', '', 'Cash', 0, '13750', 14020, '0', '0', '20,10,5,5,5,', '400,340,230,140,100,', '8th English Guide,Grammer Book,10th English Guide,9th English Guide,Competitive Exam Book,', 'Palakkari, Trichy', '', '2025-05-14', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(29, 14, 0, '', '', 'Cash', 0, '70000', 70000, '0', '0', NULL, NULL, NULL, 'Asoor, Trichy', '', NULL, 0, 'Black', '1234567890', '12345678', '1234', '', 'gfdsa54321', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `minimum_book_stock`
--

CREATE TABLE `minimum_book_stock` (
  `id` int(11) NOT NULL,
  `minimum_book_stock` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `minimum_book_stock`
--

INSERT INTO `minimum_book_stock` (`id`, `minimum_book_stock`) VALUES
(1, '10');

-- --------------------------------------------------------

--
-- Table structure for table `quotation`
--

CREATE TABLE `quotation` (
  `id` int(11) NOT NULL,
  `cid` int(11) DEFAULT NULL,
  `check_id` int(11) NOT NULL,
  `cname` varchar(225) DEFAULT NULL,
  `date` varchar(225) DEFAULT NULL,
  `mobile` varchar(225) DEFAULT NULL,
  `city` varchar(225) DEFAULT NULL,
  `net_amount` varchar(225) DEFAULT NULL,
  `total` varchar(225) DEFAULT NULL,
  `tax` varchar(225) DEFAULT NULL,
  `discount` varchar(225) DEFAULT NULL,
  `quantity` varchar(225) DEFAULT NULL,
  `price` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `remarks` varchar(225) DEFAULT NULL,
  `category_name` varchar(225) DEFAULT NULL,
  `category_option` int(11) DEFAULT NULL,
  `aadhar` varchar(225) DEFAULT NULL,
  `color` varchar(225) DEFAULT NULL,
  `chassis` varchar(225) DEFAULT NULL,
  `motor` varchar(225) DEFAULT NULL,
  `controller` varchar(225) DEFAULT NULL,
  `charger` varchar(225) DEFAULT NULL,
  `batterymodel` varchar(225) DEFAULT NULL,
  `batterysn` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quotation`
--

INSERT INTO `quotation` (`id`, `cid`, `check_id`, `cname`, `date`, `mobile`, `city`, `net_amount`, `total`, `tax`, `discount`, `quantity`, `price`, `address`, `remarks`, `category_name`, `category_option`, `aadhar`, `color`, `chassis`, `motor`, `controller`, `charger`, `batterymodel`, `batterysn`) VALUES
(2, 21, 0, 'Ajay', '2025-05-31', '1234567890', '', '90000', '94500', '5', '0', '1,', '90000,', 'Nagathi, Ammanpettai, Thanjavur', '', 'RX100,', 0, '1234567890123', 'Green', '1234ASDFGF', '1234', '12345', '123456', '1234', '2345'),
(4, 0, 0, 'Siril', '2025-05-31', '9876543210', '', '60000', '63000', '5', '0', NULL, NULL, 'Sangarakulam, Thiruppanthuruthi, Thanjavur.', '', NULL, NULL, '123456', 'White', '1234', '1234', '12345', '12345ASD', 'ASD12345', '12345'),
(5, 22, 0, 'Raja', '2025-05-31', '9876543210', '', '60000', '63000', '5', '0', '1,', '60000,', 'Trichy', '', 'Elesco,', NULL, '12345', 'White', '123456', '123456', '123', '12345', 'ASDF1234', '12345'),
(6, 0, 0, 'Ranjan', '2025-05-31', '9360648893', '', '60000', '63000', '5', '0', NULL, NULL, 'Asoor, Trichy', '', NULL, NULL, '', 'Blue', '12345', '1234', '1234', '1234567', 'ASD1234', '123'),
(7, 0, 0, 'Ranjan', '2025-05-31', '9360648893', '', '60000', '63000', '5', '0', NULL, NULL, 'Asoor, Trichy', '', NULL, NULL, '123456', 'Blue', '1234', '2345', '9876543', '6789', '5678', '567'),
(8, 0, 0, 'Ranjan', '2025-05-31', '9360648893', '', '60000', '63000', '5', '0', NULL, NULL, 'Asoor, Trichy', '', NULL, NULL, '', 'Blue', '67', '678', '678', '678', '678', '789'),
(9, 17, 9, 'Ranjan', '2025-05-31', '9360648893', '', '60000', '63000', '5', '0', '1,', '60000,', 'Asoor, Trichy', '', 'Elesco,', NULL, '', 'Blue', '67', '678', '678', '678', '678', '789'),
(10, 19, 10, 'Joshwa', '2025-05-31', '9486283460', '', '60000', '63000', '5', '0', '1,', '60000,', 'Thiruvaiyaru,\r\nThanjavur', '', 'Elesco,', NULL, '', 'Blue', '1234', '23', '234', '234', '123', '123');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `tax` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `sgst` varchar(11) NOT NULL,
  `cgst` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `tax`, `discount`, `sgst`, `cgst`) VALUES
(1, 5, 0, '2.5', '2.5');

-- --------------------------------------------------------

--
-- Table structure for table `sidebar`
--

CREATE TABLE `sidebar` (
  `menu_id` int(11) NOT NULL,
  `dashboard` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `expenses` int(11) NOT NULL,
  `sales` int(255) NOT NULL,
  `crm` varchar(255) DEFAULT NULL,
  `accounts` varchar(255) DEFAULT NULL,
  `procurement` varchar(255) DEFAULT NULL,
  `inventory` varchar(255) DEFAULT NULL,
  `stocks` varchar(255) DEFAULT NULL,
  `maintainance` varchar(255) DEFAULT NULL,
  `reports` varchar(255) DEFAULT NULL,
  `book` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sidebar`
--

INSERT INTO `sidebar` (`menu_id`, `dashboard`, `user`, `expenses`, `sales`, `crm`, `accounts`, `procurement`, `inventory`, `stocks`, `maintainance`, `reports`, `book`) VALUES
(1, 0, 0, 0, 0, '0', '0', '0', '0', '1', '0', '0', '1'),
(2, 0, 0, 0, 1, '0', '0', '0', '1', '0', '0', '0', '1'),
(3, 0, 0, 0, 0, '0', '0', '0', '0', '0', '0', '0', '0'),
(5, 0, 0, 0, 0, '0', '1', '0', '0', '1', '0', '0', '0'),
(9, 0, 0, 0, 0, '1', '1', '0', '1', '0', '0', '0', '1');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `mobile_num` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `resume` varchar(255) DEFAULT NULL,
  `proof` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `sales` int(11) NOT NULL,
  `crm` int(11) NOT NULL,
  `accounts` int(11) NOT NULL,
  `inventory` int(11) NOT NULL,
  `stocks` int(11) NOT NULL,
  `reports` int(11) NOT NULL,
  `service` int(11) NOT NULL,
  `procurement` int(11) NOT NULL,
  `load1` int(11) NOT NULL,
  `sales_order` int(11) NOT NULL,
  `invoice` int(11) NOT NULL,
  `expenses` int(11) NOT NULL,
  `income` int(11) NOT NULL,
  `date` varchar(200) DEFAULT NULL,
  `time` varchar(200) DEFAULT NULL,
  `ipaddress` varchar(100) DEFAULT NULL,
  `block` int(11) NOT NULL,
  `quotation` int(11) NOT NULL,
  `enquiry` int(11) NOT NULL,
  `customer` int(11) NOT NULL,
  `credit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `user_name`, `password`, `age`, `gender`, `mobile_num`, `city`, `email`, `pincode`, `address1`, `address2`, `remarks`, `image`, `status`, `resume`, `proof`, `role`, `sales`, `crm`, `accounts`, `inventory`, `stocks`, `reports`, `service`, `procurement`, `load1`, `sales_order`, `invoice`, `expenses`, `income`, `date`, `time`, `ipaddress`, `block`, `quotation`, `enquiry`, `customer`, `credit`) VALUES
(1, 'Diwakar M', 'Diwa11', '123', 24, 'Male', '9489460029', 'Trichy', 'diwa@gmail.com', '621010', '42 Indra Nagar', '42', 'Remarks is this', 'img.jpg', NULL, 'uploads/DIWAKAR M RESUME.pdf', 'WhatsApp Image 2023-02-19 at 1.21.10 PM.jpeg', 'User', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 0, '5/11/2023', '12:34:20', '127.0.0.1', 0, 2, 2, 2, 0),
(2, 'Arjun', 'Arjun', '123', 24, 'Male', '8976543122', 'Trichy', 'arjun@gmail.com', '621010', '42', '42', 'No remarks', '1.jpg', NULL, 'DIWAKAR M RESUME.pdf', 'WhatsApp Image 2023-02-19 at 1.21.10 PM.jpeg', 'User', 2, 2, 0, 0, 0, 0, 0, 2, 2, 2, 2, 0, 0, '28/9/2023', '11:34:17', '127.0.0.1', 0, 0, 0, 0, 0),
(3, 'Gokul', 'Gokul', '123', 23, 'Male', '9323311134', 'Trichy', 'gokul@gmail.com', '621010', '42', '42', 'Hwello', 'gokul.jpg', NULL, 'DIWAKAR M RESUME.pdf', 'WhatsApp Image 2023-02-19 at 1.21.10 PM.jpeg', 'User', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '15/10/2023', '11:29:49', '::1', 0, 0, 0, 0, 0),
(5, 'Dhaksen', 'Dhaks', '123', 6, 'Male', '9347324611', 'Trichy', 'dhaks@gmail.com', '621010', '24', '2', 'This is the remarks', 'dhakshu.jpg', NULL, 'DIWAKAR M RESUME.pdf', 'WhatsApp Image 2023-02-19 at 1.21.10 PM.jpeg', 'User', 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, '1/10/2023', '21:39:7', '127.0.0.1', 0, 0, 0, 0, 0),
(9, 'Satheesh', 'satheesh', '123', 23, 'Male', '9423112232', 'Trichy', 'satheesh@gmail.com', '621010', '42 Indra Nagar', '42 Indra Nagar', 'This is a remarks', 'client-img.png', NULL, 'DIWAKAR M RESUME.pdf', 'WhatsApp Image 2023-02-19 at 1.21.10 PM.jpeg', 'User', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, '27/9/2023', '16:25:39', '127.0.0.1', 0, 0, 0, 0, 0),
(12, 'Admin', 'admin', '123', 25, 'Male', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'admin.png', NULL, 'DIWAKAR M RESUME.pdf', 'WhatsApp Image 2023-02-19 at 1.21.10 PM.jpeg', 'Admin', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '31/5/2025', '15:29:52', '::1', 0, 1, 1, 1, 0),
(16, 'Francis', 'Francis', '123', 22, 'Male', '9876543234', 'Goa', 'vishnu@gmail.com', '621001', '42 Indra Nagar', NULL, 'How is it', '8.jpg', NULL, 'DIWAKAR M RESUME.pdf', 'WhatsApp Image 2023-02-19 at 1.21.10 PM.jpeg', 'User', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '27/9/2023', '16:25:58', '127.0.0.1', 0, 0, 0, 0, 0),
(17, 'Priya', 'priya', '123', 23, 'Female', '9099932123', 'Namakkal', 'priyav@gmail.com', '637001', 'Namakkal', NULL, 'Great', 'thanishka.jpg', NULL, 'DIWAKAR M RESUME.pdf', 'WhatsApp Image 2023-02-19 at 1.15.40 PM.jpeg', 'User', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7/11/2023', '11:30:5', '127.0.0.1', 0, 0, 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `all_tabs`
--
ALTER TABLE `all_tabs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `credit`
--
ALTER TABLE `credit`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `credit1`
--
ALTER TABLE `credit1`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer1`
--
ALTER TABLE `customer1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `delivery_type`
--
ALTER TABLE `delivery_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `district`
--
ALTER TABLE `district`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `minimum_book_stock`
--
ALTER TABLE `minimum_book_stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quotation`
--
ALTER TABLE `quotation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sidebar`
--
ALTER TABLE `sidebar`
  ADD PRIMARY KEY (`menu_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `all_tabs`
--
ALTER TABLE `all_tabs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `credit`
--
ALTER TABLE `credit`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `credit1`
--
ALTER TABLE `credit1`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `customer1`
--
ALTER TABLE `customer1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `delivery_type`
--
ALTER TABLE `delivery_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `district`
--
ALTER TABLE `district`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `minimum_book_stock`
--
ALTER TABLE `minimum_book_stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `quotation`
--
ALTER TABLE `quotation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `sidebar`
--
ALTER TABLE `sidebar`
  MODIFY `menu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
