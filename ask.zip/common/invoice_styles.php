<style>
    table{
        width:100%;
        color:black;
    }
    td{
        vertical-align: top; 
    }
    tr>td:nth-child(1),tr>td:nth-child(3){
        width:5%;
    }
    tr>td:nth-child(2),tr>td:nth-child(7){
        width:36%;
    }
    tr>td:nth-child(3),tr>td:nth-child(4),tr>td:nth-child(5){
        width:2%;
    }
    td{
        border:0.5px solid black;
        font-size:18px;
    }
    .no_box{
        color:white;
        border-color:white;
        border-left:1px solid black;
        border-right:1px solid black;
        border-bottom:1px solid black;
        height:250px;
        min-height:330px;
        max-height:330px;
    }
    .content{
        margin-left: -150px;
    }
    /* .over{
        font-size: 16;
    } */
    td img {
        width:350px; /* Make it fill the cell's width */
        height:100px; /* Maintain aspect ratio */
    }
    .myDiv22{
        gap:24%;
    }
    th{
        color:white;
        background:#c21b72!important;
        font-size:18px!important;
        border:0.5px solid black;
    }
    .urls{
        color:black!important;
    }
    .head_text{
        font-size:18px!important;
        text-transform:uppercase;
    }
</style>